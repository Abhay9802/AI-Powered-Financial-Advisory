# 4-minute viva preparation

**1. Explain your project.**  
My project uses Generative AI and n8n to organise financial enquiries. It receives an enquiry, summarises it, classifies the level of interest and suggests an educational follow-up. It flags personal investment recommendations for human review.

**2. Why did you select this topic?**  
Financial service teams receive repeated questions. AI can help organise these enquiries and reduce repetitive manual work. It is also relevant to business management because it combines automation, analytics and decision-making.

**3. What is n8n?**  
n8n is a low-code workflow automation platform. It connects different applications and moves data between workflow steps.

**4. What is a webhook?**  
A webhook is a URL that receives an event or data from another application and starts the workflow.

**5. What is Generative AI doing?**  
It understands the customer's written enquiry, creates a short summary and returns a structured classification. It does not choose an investment product.

**6. Explain your dataset.**  
I created 500 fictional lead records. The scenario has 120 qualified leads, 39 meetings and 3 conversions. The data is hypothetical and does not represent actual company results.

**7. Explain your KPIs.**  
Qualified rate is 120 divided by 500, or 24%. Meeting rate is 39 divided by 500, or 7.8%. Meeting-to-conversion is 3 divided by 39, or about 7.69%. Overall conversion is 3 divided by 500, or 0.6%.

**8. What are the main risks?**  
Incorrect AI outputs, privacy issues, bias, lack of consent and over-reliance on automation. I address these through synthetic data, restricted prompts, secure credentials and human review.

**9. What is the main limitation?**  
This is a prototype. It needs an API key and n8n setup, and it has not been tested with live business data.

**10. What is the conclusion?**  
AI can support employees by organising information and improving visibility. Human professionals must remain responsible for financial advice and final decisions.
