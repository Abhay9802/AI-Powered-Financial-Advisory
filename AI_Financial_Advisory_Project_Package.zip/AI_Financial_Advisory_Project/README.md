# AI-Powered Financial Advisory Lead Management and Enquiry Triage

**Course:** AI for Managers (PMC30022), IILM University, Greater Noida  
**Student:** Simran Panjwani  
**Data:** Entirely synthetic / hypothetical.

## Files
- `AI_Financial_Advisory_Project_Report.pdf` — submission report
- `AI_Financial_Advisory_Project_Report.docx` — editable report
- `AI_Financial_Advisory_Project_Presentation.pptx` — 6-minute presentation
- `n8n_workflow_import.json` — importable n8n workflow template
- `synthetic_lead_dataset_500.csv` — 500 fictional lead records
- `lead_funnel.png` — KPI funnel chart
- `sample_webhook_payload.json` — test request body

## Run the n8n prototype
1. Open your n8n instance and create/import a workflow using `n8n_workflow_import.json`.
2. Add your OpenAI API key securely. The template contains `YOUR_OPENAI_API_KEY` as a placeholder; never commit a real key to GitHub.
3. Open the Webhook node and click **Listen for test event**.
4. Send a POST request to the displayed test URL with the sample JSON payload.
5. Inspect the response. The expected response includes a `lead_analysis` object and a disclaimer.
6. After testing, configure credentials securely, review privacy/security settings, then activate/publish and use the production URL.

The workflow uses the OpenAI Chat Completions API with `gpt-4o-mini`. If your account does not support this model, select an available compatible model in the HTTP Request body. API usage may incur charges and requires an API key.

## Sample payload
See `sample_webhook_payload.json`.

## Academic safeguards
This is an educational lead-triage prototype, not a financial advisory system. It does not recommend funds, securities, allocations or returns. Personalised requests must be handled by an appropriately qualified/registered human professional. Do not use real customer data in the demo.

## GitHub submission
Create a public GitHub repository, upload these project files, and paste its public URL into the report's Appendix B. Do not upload API keys, private client data or credentials.

## Suggested viva questions
1. What business problem does the project solve?
2. Why did you choose Generative AI instead of only fixed rules?
3. What is the role of n8n?
4. What does the Webhook node do?
5. How does the system flag a request for human review?
6. What are the four KPIs and how are they calculated?
7. Why is the dataset synthetic?
8. What are hallucinations and how are they controlled?
9. Why should the AI not recommend a specific mutual fund?
10. What would you improve before using this in a real business?
